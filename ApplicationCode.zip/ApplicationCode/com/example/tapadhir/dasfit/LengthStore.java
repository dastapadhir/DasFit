package com.example.tapadhir.dasfit;

/**
 * Created by Tapadhir on 12/21/2017.
 */

public class LengthStore {

    public static int fullname_length;
    public static int uuid_length;
    public static int password_length;
    public static int retyped_length;

}
