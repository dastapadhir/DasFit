package com.example.tapadhir.dasfit;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Tapadhir on 12/24/2017.
 */

public class UserProfile extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userprofile);
        Button back = (Button) findViewById(R.id.userprofileback); //Configuring the back button
        back.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v) {
                goToDeviceManager(); //Go to the Corresponding slide
            }
        });
        Button start = (Button) findViewById(R.id.startworkout); //Configuring the back button
        start.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v) {
                goToStartWorkout(); //Go to the Corresponding slide
            }
        });
        Button log = (Button) findViewById(R.id.workoutlog); //Configuring the back button
        log.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v) {
                goToWorkLog(); //Go to the Corresponding slide
            }
        });


    }
    public void goToDeviceManager()
    {
        Intent intent = new Intent(this, DeviceManager.class); //Definition of DeviceList class (Tapadhir)
        startActivity(intent);
    }
    public void goToUserProfile()
    {
        Intent intent = new Intent(this, UserProfile.class); //Definition of DeviceList class (Tapadhir)
        System.out.println(intent);
        startActivity(intent);
    }
    public void goToStartWorkout()
    {
        Intent intent = new Intent(this, StartWorkout.class);
        System.out.println(intent);
        startActivity(intent);
    }
    public void goToWorkLog()
    {
        Intent intent = new Intent(this, Work_Log.class); //Definition of DeviceList class (Tapadhir)
        startActivity(intent);
    }

}
