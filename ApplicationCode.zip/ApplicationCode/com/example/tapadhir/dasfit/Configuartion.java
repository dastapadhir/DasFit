package com.example.tapadhir.dasfit;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;

import java.io.FileOutputStream;
import java.util.regex.Pattern;

public class Configuartion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configuration);
        Button back_button= (Button) findViewById(R.id.configuration_back_button); //Configuring the back button
        back_button.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v)
            {
                goToMainActivity(); //Go to the Corresponding slide
            }
        });

        final EditText configure_fullname_editText = (EditText) findViewById(R.id.fullname_editText); //Configuring the fullname editText
        final EditText configure_password_editText = (EditText) findViewById(R.id.password_editText); //Configuring the password editText
        final EditText configure_retype_password_editText = (EditText) findViewById(R.id.retype_editText); //Configuring the retyped editText
        final EditText height_editText = (EditText) findViewById(R.id.heightedittext);
        final EditText weight_editText = (EditText) findViewById(R.id.weightedittext);
        Button configure_my_device_configure_button = (Button) findViewById(R.id.configuration_configure_button); //Configuring the configure button
        configure_my_device_configure_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View V) {
                String Fullname = configure_fullname_editText.getText().toString(); //Gets the value from the full name text field
                String Password = configure_password_editText.getText().toString();// Gets the value from password field
                String RetypedPassword = configure_retype_password_editText.getText().toString();//Gets the value from retype text field
                String Heightstring = height_editText.getText().toString();
                String Weightstring = weight_editText.getText().toString();
                int height = Integer.valueOf(Heightstring);
                int weight = Integer.valueOf(Weightstring);
                int fullname_length = Fullname.length(); //Length of the fullname entered
                int password_length = Password.length(); //Length of the password entered
                int retypedpassword_length = RetypedPassword.length(); //Length of the retyped password entered
                //Setting all the lengths to the Length class (Tapadhir)
                LengthStore.fullname_length = fullname_length;
                LengthStore.password_length = password_length;
                LengthStore.retyped_length = retypedpassword_length;
                if (!Password.equals(RetypedPassword)) //Checking if the password and retyped password are the same
                {
                    //Setting the fields back to NULL
                    configure_fullname_editText.setText(" ");
                    configure_password_editText.setText("");
                    configure_retype_password_editText.setText("");
                    height_editText.setText(" ");
                    weight_editText.setText(" ");
                    Toast.makeText(getApplicationContext(), "Invalid Data Entry. Please Try Again", Toast.LENGTH_SHORT).show(); //Display Error Message
                }
                //Clearing out the text fields
                configure_fullname_editText.setText(" ");
                configure_password_editText.setText("");
                configure_retype_password_editText.setText("");
                height_editText.setText(" ");
                weight_editText.setText(" ");
                Telemetry telemetry = new Telemetry();
                telemetry.height = height;
                telemetry.weight = weight;
                Toast.makeText(getApplicationContext(), "Data Saved.", Toast.LENGTH_SHORT).show(); //Display Success Message
                String FILENAME = "myfile"; //Writing to the file
                FileOutputStream outputStream; //Outputting to the file
                try
                {
                    outputStream = openFileOutput(FILENAME, Context.MODE_PRIVATE); //Open the file. Only the S&S App can use this
                    outputStream.write(Fullname.getBytes());//Writing the data to the file
                    outputStream.write(Password.getBytes());
                    outputStream.write(RetypedPassword.getBytes());
                    outputStream.close(); //Closing the file
                    boolean test = FileExistence(FILENAME); //test to see if the file exists
                } catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
            });
    }
    public void goToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class); //Definition of MainActivity class (Tapadhir)
        startActivity(intent);
    }
    public boolean FileExistence(String name)
    {
        File file= getBaseContext().getFileStreamPath(name);
        System.out.println("File Existence: " + file.exists());
        return file.exists();
    }
}
