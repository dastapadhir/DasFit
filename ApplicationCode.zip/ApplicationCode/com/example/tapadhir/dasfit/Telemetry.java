package com.example.tapadhir.dasfit;

/**
 * Created by Tapadhir on 3/1/2018.
 */

public class Telemetry {
    public static int steps ;
    public static double calories;
    public static double distance_travelled;
    public static int height;
    public static int weight;
}
