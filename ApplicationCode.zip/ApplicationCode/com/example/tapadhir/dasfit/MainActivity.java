package com.example.tapadhir.dasfit;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.bluetooth.BluetoothAdapter;
import android.widget.ImageButton;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("Inside of Main Activity");
        BluetoothAdapter Bluetooth_Adapter = BluetoothAdapter.getDefaultAdapter();
        Bluetooth_Adapter.getDefaultAdapter().enable(); //Turns on in phone bluetooth
        Button device_button = (Button) findViewById(R.id.device_button); //Configuring the back button
        device_button.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v)
            {
                System.out.println("Inside of OnClick");
                String BLUETOOTH;              //Initiates bluetooth control and pairing
                String BLUETOOTH_ADMIN;        //Initiates bluetooth discovery and pairing
                int REQUEST_ENABLE_BT = 1;
                BluetoothAdapter Bluetooth_Adapter = BluetoothAdapter.getDefaultAdapter(); //Default instance for a Bluetooth object
                if (Bluetooth_Adapter == null) //Checking if there is no bluetooth capability on device
                {
                    System.out.println("This device does not support Bluetooth");
                }
                Bluetooth_Adapter.getDefaultAdapter().enable(); //Turns on Bluetooth
                if (Bluetooth_Adapter.isDiscovering()) //Checking if bluetooth is discovering currently
                {
                    Bluetooth_Adapter.cancelDiscovery(); //Stops the Discovery
                }
                Bluetooth_Adapter.startDiscovery();//Start a New Discovery
                IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND); //Setting a new intent
                registerReceiver(mReceiver, filter); //Send the receiver
                goToDeviceManager(); //Go to the Corresponding slide
            }
        });

        Button configure = (Button) findViewById(R.id.setup_button); //Configuring the back button
        configure.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v)
            {
                goToConfigure(); //Go to the Corresponding slide
            }
        });
    }
    public void goToMainActivity()
    {
        Intent intent = new Intent(this, MainActivity.class); //Definition of MainActivity class (Tapadhir)
        System.out.println(intent);
        startActivity(intent);
    }
    public void goToConfigure()
    {
        Intent intent = new Intent(this, Configuartion.class);
        System.out.println(intent);
        startActivity(intent);
    }
    public void goToDeviceManager()
    {
        Intent intent = new Intent(this, DeviceManager.class);
        System.out.println(intent);
        startActivity(intent);
    }
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() //Starting BroadCast Receiver to detect devices
    {
        /**************************************************************
         *	  Purpose:  To detect the surrounding devices and along with their names and MAC addresses.
         *
         *    Entry:    Takes in the Context of the class along with an intent
         *
         *    Exit:     Finds out the list of discoverable devices in the area along with
         *              corresponding names and MAC addresses.
         ****************************************************************/
        public void onReceive(Context context, Intent intent) //When detecting a device
        {
            System.out.println(context);
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) //If device is found
            {
                // Discovery has found a device. Get the BluetoothDevice object and its info from the Intent.
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                String deviceName = device.getName(); //Name of Bluetooth Device
                String deviceHardwareAddress = device.getAddress(); // MAC address
            }
        }
    };
}
