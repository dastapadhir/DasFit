package com.example.tapadhir.dasfit;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.os.ParcelUuid;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.bluetooth.BluetoothClass;
import android.content.Intent;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import android.view.Menu;
import android.view.MenuInflater;

/**
 * Created by Tapadhir on 12/24/2017.
 */

public class Connection extends AppCompatActivity
{
    //Setting up the variables
    private static OutputStream mmOutStream;
    private static InputStream mmInStream;
    public static int comm=0;  //The number of times a Rf connection is made
    public static BluetoothSocket mmSocket;
    BluetoothDevice mmDevice;
    byte[] data = {12, 23, 34, 45};
    byte[] buffer = new byte[4];
    BluetoothAdapter bluetoothAdapter = DeviceManager.bluetoothAdapter;
    final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");  //UUID for HC-05
    public void SocketConnection(BluetoothDevice result, final String message)
    {
        System.out.println("BT Device:" + result);
        System.out.println("String : " + message);
        mmDevice = result;//Setting the device
        final String n_message=message; //Taking in the string passed through
        InputStream tmpIn = null;
        OutputStream tmpOut = null;
        Thread BluetoothConnection = new Thread()  //New thread for Bluetooth Socket
        {
            @Override
            public void run()
            {
                System.out.println("Inside Run()");
                bluetoothAdapter.cancelDiscovery(); //Cancel current discovery
                try
                {
                    if(message.equals("STOP"))
                    {
                        System.out.println("The entered message is " + message);
                        System.out.println("Intent { cmp=com.example.tapadhir.dasfit/.WorkoutLog }");
                        mmSocket.close();
                    }
                    if(comm==0) //If a socket had never been created, create a rf connection
                    {
                        mmSocket = mmDevice.createRfcommSocketToServiceRecord(MY_UUID); //Creating of Socket
                        comm=1;
                    }
                    if (!mmSocket.isConnected()) //If the socket is not connected, connect the socket
                    {
                        mmSocket.connect(); //Connecting the Bluetooth

                    }
                    ConnectedThread mmConnect = new ConnectedThread(mmSocket, n_message); //Write bytes through the bluetooth socket
                }
                catch (IOException e1)
                {
                    e1.printStackTrace();
                    System.out.println("Socket could not be created");
                    try
                    {
                        mmSocket.connect();
                        System.out.println("Successfully closed the socket");
                    }
                    catch (IOException closeException)
                    {
                        System.out.println("Unable to close the socket");

                    }
                }
            }
        };
        BluetoothConnection.start(); //Starting the thread
    }
}
