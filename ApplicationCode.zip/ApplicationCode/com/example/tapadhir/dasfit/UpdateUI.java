package com.example.tapadhir.dasfit;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by Tapadhir on 1/4/2018.
 */

public class UpdateUI extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startactivity);

    }
    public void UpdateTextView(int value)
    {
        TextView steps = (TextView) findViewById(R.id.steptextview);
        steps.setText(value);
    }
}
