package com.example.tapadhir.dasfit;

import android.app.Activity;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.bluetooth.BluetoothAdapter;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;

import org.w3c.dom.Text;

import static com.example.tapadhir.dasfit.R.id.steptextview;
import static com.example.tapadhir.dasfit.R.id.textView;
import static com.example.tapadhir.dasfit.StartWorkout.telemetry;

/**
 * Created by Tapadhir on 12/24/2017.
 */

public class ConnectedThread extends Thread{

    BluetoothAdapter Bluetooth_Adapter;
    public BluetoothSocket mmSocket;
    public InputStream mmInStream;
    public OutputStream mmOutStream;
    public byte[] mmBuffer = {12, 23, 34, 45, 56, 67, 78, 89, 90}; // mmBuffer store for the stream
    int writevalue = 0;
    int prev_datavalue = 0;
    int stepvalue = 0;
    String stringstep = " ";
    double distance_travelled = 0;
    double calories_per_step = 0;
    double totalcalories = 0;
    double stride_length = 0.0;
    int inches_in_mile = 63380;
    Context context;
    public ConnectedThread(BluetoothSocket socket, String message) {
        System.out.println("Inside ConnectedThread()");
        System.out.println("Bluetooth Socket: " + socket);
        System.out.println("Message : " + message);
        mmSocket = socket;
        InputStream tmpIn = null;
        OutputStream tmpOut = null;
        try
        {
            tmpIn = socket.getInputStream(); //Make an input stream
        } catch (IOException e)
        {
            System.out.println("Error occurred when creating input stream");
            e.printStackTrace();
        }
        try
        {
            tmpOut = socket.getOutputStream(); //Make an output stream
        } catch (IOException e)
        {
            System.out.println("Error occurred when creating output stream");
            e.printStackTrace();
        }
        mmInStream = tmpIn;
        mmOutStream = tmpOut;
        write(message, mmSocket); //Write bytes over the bluetooth
    }

    /**************************************************************
     * Purpose:  To send a byte of data over the bluetooth socket
     * <p>
     * Entry:    The string command to be sent over the bluetooth
     * socket.
     * <p>
     * Exit:     The function doesn't return anything
     ****************************************************************/
    public void write(String message, BluetoothSocket mmSocket) {
        System.out.println("Inside Write()");
        System.out.println("Bluetooth Socket: " + mmSocket);
        System.out.println("Message : " + message);
        byte[] testresult = message.getBytes(); //Turn the string into bytes
        try
        {
            for (int i = 0; i <= 5000; i++)
            {
                if (i == 5000)
                {
                    mmOutStream.write(testresult, 0, testresult.length); //write data to the socket
                    Read();
                    i = 0;
                }
            }
        } catch (IOException e)
        {

        }
    }

    public void Read() {
        int finalvalue = 0;
        mmBuffer = new byte[10];
        int numBytes = 0; // bytes returned from read()
        int dataAvailableCount = 0;
        try
        {
            // Read from the InputStream.
            dataAvailableCount = mmInStream.available(); //Check the number of bytes sent back from the microcontroller
            byte[] result = new byte[dataAvailableCount]; //Making an array with appropriate elements
            numBytes = mmInStream.read(); //Read the data being read
            System.out.println("Raw data : " + numBytes);
            finalvalue = DataFilter(numBytes);
            final Telemetry telemetry = new Telemetry();
            stride_length = HeightIndex(telemetry.height);
            calories_per_step = Calories(inches_in_mile,stride_length,telemetry.weight);
            distance_travelled = finalvalue * stride_length;
            totalcalories = finalvalue * calories_per_step;
            System.out.println("Steps Taken : " + finalvalue);
            System.out.println("Distance Travelled : " + distance_travelled);
            System.out.println("Calories Burned : " + totalcalories);
            telemetry.steps = finalvalue;
            telemetry.calories = totalcalories;
            telemetry.distance_travelled = distance_travelled;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("Input stream was disconnected");
        }
    }



    public int DataFilter(int numBytes) {
        if (numBytes == 97)
        {
            prev_datavalue = 97;
        } else
        {
            if (prev_datavalue == 97)
            {
                prev_datavalue = numBytes;
                switch (numBytes)
                {
                    case 48:
                        stringstep = "0";
                        break;
                    case 49:
                        stringstep = "1";
                        break;
                    case 50:
                        stringstep = "2";
                        break;
                    case 51:
                        stringstep = "3";
                        break;
                    case 52:
                        stringstep = "4";
                        break;
                    case 53:
                        stringstep = "5";
                        break;
                    case 54:
                        stringstep = "6";
                        break;
                    case 55:
                        stringstep = "7";
                        break;
                    case 56:
                        stringstep = "8";
                        break;
                    case 57:
                        stringstep = "9";
                        break;
                }
                stepvalue = Integer.parseInt(stringstep);
                System.out.println("Step value retrieved is " + stepvalue);
            } else
            {
                prev_datavalue = numBytes;
                switch (numBytes)
                {
                    case 48:
                        stringstep = stringstep + "0";
                        break;
                    case 49:
                        stringstep = stringstep + "1";
                        break;
                    case 50:
                        stringstep = stringstep + "2";
                        break;
                    case 51:
                        stringstep = stringstep + "3";
                        break;
                    case 52:
                        stringstep = stringstep + "4";
                        break;
                    case 53:
                        stringstep = stringstep + "5";
                        break;
                    case 54:
                        stringstep = stringstep + "6";
                        break;
                    case 55:
                        stringstep = stringstep + "7";
                        break;
                    case 56:
                        stringstep = stringstep + "8";
                        break;
                    case 57:
                        stringstep = stringstep + "9";
                        break;
                }
                stepvalue = Integer.parseInt(stringstep);
                System.out.println("Step value retrieved is " + stepvalue);
            }
        }
        return stepvalue;
    }

    public double HeightIndex(int height) {
        System.out.println("Height in inches :" + height);
        double index = 0.0;
        if (height < 66) index = 25.7;
        else if (height >= 66 && height <= 72) index = 27.64;
        else index = 30.0;
        System.out.println("Index: " + index);
        return index;
    }

    public double Calories(int inches_in_mile, double stride_length, int weight)
    {
        System.out.println("Weight :" + weight);
        double weightindex = 0.57;
        double steps_in_mile = inches_in_mile/stride_length;
        double calories_in_miles = weight*weightindex;
        double calories = calories_in_miles/steps_in_mile;
        System.out.println ("Calories : " + calories);
        return calories;
    }
}

