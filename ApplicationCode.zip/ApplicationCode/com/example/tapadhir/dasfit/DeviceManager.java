package com.example.tapadhir.dasfit;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.os.SystemClock;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.bluetooth.BluetoothClass;
import android.content.Intent;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import static android.app.AlertDialog.THEME_HOLO_LIGHT;

/**
 * Created by Tapadhir on 12/22/2017.
 */

public class DeviceManager extends AppCompatActivity
{
    public static BluetoothSocket mmSocket;
    public static BluetoothDevice mmDevice;
    int fullname_length=0;
    int uuid_length=0;
    int password_length=0;
    String fullname;
    String uuid;
    String password;
    private EditText m_edittext;
    private TextView m_textview;
    String flag = "ON" ;
    public static BluetoothAdapter bluetoothAdapter;
    BluetoothAdapter Bluetooth_Adapter;
    Set<BluetoothDevice> pairedDevices;
    ListView listView;
    String m_Text="";
    Context ctx;
    Context context;
    UUID MY_UUID = UUID.fromString("0000110E-0000-1000-8000-00805F9B34FB"); //Default UUID for the HC-05 bluetooth used in the lock
    BluetoothDevice result = null;
    volatile boolean threadend=false;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.devicemanager);
        listView=(ListView)findViewById(R.id.device_listview); //Setting up the Listview
        bluetoothAdapter=BluetoothAdapter.getDefaultAdapter(); //Setting up Bluetooth Adapter
        ctx=this; //Pointing to DeviceList.class
        GenerateList(); //Generate the Bluetooth List
        Button back_button_device_list = (Button) findViewById(R.id.device_backbutton); //Configuring the button
        back_button_device_list.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v)
            {
                goToMainActivity(); //Go to the Corresponding slide
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        { //Waits for the Listview to click
            public void onItemClick(AdapterView parent, View v, int position, long id) //When you click a device on listview
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(ctx); //Setting up an alert
                builder.setTitle("ENTER PASSCODE"); //Default Text
                final EditText input = new EditText(ctx);
                input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
                builder.setView(input); //Setting the view
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() //Setting up the positve button
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        m_Text = input.getText().toString(); //Taking the inputted string
                        String FILENAME = "myfile"; //file from internal storage
                        try
                        {
                            FileInputStream fin = openFileInput(FILENAME); //Open file from internal storage
                            int c;
                            String temp="";
                            while((c=fin.read())!=-1) //Reading until the file is empty
                            {
                                temp=temp+Character.toString((char)c); //Extracting the string one by one character
                            }
                            //Receiving all the stored lengths in the LengthStore.class
                            fullname_length=LengthStore.fullname_length;
                            uuid_length=LengthStore.uuid_length;
                            password_length=LengthStore.password_length;
                            DataExtraction(temp); //Extract the data from the stored string
                            PasswordTest(m_Text); //Test for password equalness
                            System.out.println("Returned from password test function ");
                            //goToUserProfile();
                        } catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() //Setting up the negative button
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        dialog.cancel(); //Cancel the dialog
                    }
                });
                builder.show(); //show the dialog
            }
        });
    }
    /**************************************************************
     *	  Purpose:  To go back to the opening screen of the app
     *
     *    Entry:    No parameters taken.
     *
     *    Exit:     Takes the application to the MainActivity.class slide
     ****************************************************************/
    private void goToMainActivity()
    {
        Intent intent = new Intent(this, MainActivity.class); //Definition of DeviceList class (Tapadhir)
        startActivity(intent);
    }
    /**************************************************************
     *	  Purpose:  To generate a listview of appropriate devices that
     *	            are detected by the application's bluetooth.
     *
     *    Entry:    No parameters taken.
     *
     *    Exit:     Puts all the devices detected, along with corresponding
     *              names and MAC addresses in a listview
     ****************************************************************/
    public void GenerateList()
    {
        pairedDevices=bluetoothAdapter.getBondedDevices(); //Get the list of all paired devices
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1); //Setting up Array Adapter
        ArrayList List = new ArrayList<String>(); //Setting Array List
        if(pairedDevices.size() > 0)
        {
            for (BluetoothDevice bt : pairedDevices) //Iterate through the list of paired devices
            {
                String device_name=bt.getName(); //Get name of device
                String device_address=bt.getAddress(); //Get address of device
                adapter.add(device_name + "\n" + device_address); //Add to Array Adapter
            }
            Toast.makeText(getApplicationContext(), "Showing Currently Paired Devices", Toast.LENGTH_SHORT).show();
        }
        listView.setAdapter(adapter); //Hook up to the ListView
    }
    /**************************************************************
     *	  Purpose:  To extract the data into separate strings from
     *	            the giant string of data retrieved from the file.
     *
     *    Entry:    String of data retrieved from the input file
     *
     *    Exit:     Extracts retrieved data into separate strings
     ****************************************************************/
    public void DataExtraction(String temp)
    {
        System.out.println("String temp : " + temp);
        fullname=temp.substring(0,fullname_length); //Extracting the fullname
        uuid=temp.substring(fullname_length, temp.length()-2*(password_length)); //Extracting the device uuid
        password=temp.substring(fullname_length+uuid_length,temp.length()-password_length); //Extracting the password
    }
    /**************************************************************
     *	  Purpose:  To test the typed in password with the already configured password.
     *
     *    Entry:    Entered string into the password field of Dialog.
     *
     *    Exit:     Successful password entry will open up the bluetooth options
     *              dialog.
     ****************************************************************/
    public void PasswordTest(String m_Text)
    {
        System.out.println("String m_Text : " + m_Text);
        if(!m_Text.equals(password)) //If typed password is not equal to configured password
        {
            Toast.makeText(getApplicationContext(), "Incorrect Password. Try Again", Toast.LENGTH_SHORT).show(); //Display error message
            return;
        }
        else
        {
            //return;
            //FindDevice();
            goToUserProfile();
            return;
        }
    }
    /**************************************************************
     *	  Purpose:  To find the appropriate device by it's name and showcase the
     *	            bluetooth options dialog for a choice in operations.
     *
     *    Entry:    No parameters are entered.
     *
     *    Exit:    It will find the appropriate device. Depending on the option selected,
     *             a specific string will be sent when a bluetooth connection is created.
     ****************************************************************/
    public void goToUserProfile()
    {
        Intent intent = new Intent(this, UserProfile.class); //Definition of DeviceList class (Tapadhir)
        System.out.println(intent);
        startActivity(intent);
    }
}

