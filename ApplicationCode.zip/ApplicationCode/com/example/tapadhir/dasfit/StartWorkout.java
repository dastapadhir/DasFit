package com.example.tapadhir.dasfit;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.SystemClock;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.bluetooth.BluetoothClass;
import android.content.Intent;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import static android.app.AlertDialog.THEME_HOLO_LIGHT;



/**
 * Created by Tapadhir on 1/3/2018.
 */

public class StartWorkout extends AppCompatActivity {
    BluetoothDevice result = null;
    public static String message;
    public static Telemetry telemetry = new Telemetry();
    public static BluetoothAdapter Bluetooth_Adapter = BluetoothAdapter.getDefaultAdapter();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.startactivity);
        Button stopworkout = (Button) findViewById(R.id.stopworkoutbutton); //Configuring the back button
        stopworkout.setOnClickListener(new View.OnClickListener() //Waiting for it to Click
        {
            @Override
            public void onClick(View v) {
                message = "STOP"; //Send the Open String command
                Connection connection = new Connection();
                connection.SocketConnection(result, message); //Create a bluetooth socket
            }
        });
        String device_name = "HC-05"; //Standard bluetooth module name that Smart and Secure uses.
        Set<BluetoothDevice> devices = Bluetooth_Adapter.getBondedDevices(); //Get a list of all bonded devices
        if (devices != null)
        {
            for (BluetoothDevice device : devices) //Iterate through all the devices
            {
                if (device_name.equals(device.getName()))  //If appropr/iate device is found
                {
                    result = device;
                    message = "O"; //Send the Open String command
                    Connection connection = new Connection();
                    connection.SocketConnection(result, message); //Create a bluetooth socket
                    break;
                }
            }
        }
    }
}