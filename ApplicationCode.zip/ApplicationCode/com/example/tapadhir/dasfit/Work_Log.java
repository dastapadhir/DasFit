package com.example.tapadhir.dasfit;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by Tapadhir on 3/1/2018.
 */

public class Work_Log extends AppCompatActivity{
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.work_log);
        int stepvalue = 0;
        double calories= 0;
        double distance_travelled = 0;
        Telemetry telemetry = new Telemetry();
        stepvalue = telemetry.steps;
        calories = telemetry.calories;
        distance_travelled = telemetry.distance_travelled;
        distance_travelled = distance_travelled/63380;
        String finaldistance = new Double(distance_travelled).toString();
        String finalcalories = new Double(calories).toString();
        finaldistance = String.format("%.2f", distance_travelled);
        finalcalories = String.format("%.2f", calories);
        TextView stepdisplay = (TextView) findViewById(R.id.steptextview);
        stepdisplay.setText(Integer.toString(stepvalue) + " steps");
        TextView caloriesdisplay = (TextView) findViewById(R.id.caloriestextview);
        caloriesdisplay.setText(finalcalories + " calories");
        TextView distancedisplay = (TextView) findViewById(R.id.distancetextview);
        distancedisplay.setText(finaldistance + " miles");
    }
}
