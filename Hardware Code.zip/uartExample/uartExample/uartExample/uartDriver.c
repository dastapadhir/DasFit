/*************************************************************
* Author:			Troy Scevers
* Filename:			uartDriver.c
* Date Created:		03/29/17
* Modifications:	
**************************************************************/
// Defines

// Include Files
#include <avr/io.h>
#include <stdio.h>
#include "uartDriver.h"
#include <util/setbaud.h>

/**********************************************************************
* Purpose: This function initializes the UART driver.
*
* Precondition:		
*     F_CPU must be declared in project or defined
*
* Postcondition:
*      Sets up UART to be used for IO
*
************************************************************************/
//void uart_init(void)
//{
    //UBRR0H = UBRRH_VALUE;
    //UBRR0L = UBRRL_VALUE;
//
//#if USE_2X
    //UCSR0A |= _BV(U2X0);
//#else
    //UCSR0A &= ~(_BV(U2X0));
//#endif
//
    //UCSR0C = _BV(UCSZ01) | _BV(UCSZ00); /* 8-bit data */
    //UCSR0B = _BV(RXEN0) | _BV(TXEN0);   /* Enable RX and TX */
//}

/**********************************************************************
* Purpose: This function sends a character to the uart.
*
* Precondition:
*     stream - FILE stream must be declared before use.
*     c      - Character to send
*
* Postcondition:
*      Returns nothing (return value is for compatablility.
*
************************************************************************/
int uart_putcharacter(char c, FILE *stream)
{
	if (c == '\n')
	{
		uart_putcharacter('\r', stream);
	}
	
	loop_until_bit_is_set(UCSR0A, UDRE0);
	UDR0 = c;

	return 0;
}
/**********************************************************************
* Purpose: This function sends a character to the uart.
*
* Precondition:
*     stream - FILE stream must be declared before use.
*     c      - Character to send
*
* Postcondition:
*      Returns nothing (return value is for compatablility.
*
************************************************************************/
int uart_putbyte(unsigned char data)
{
	while (!(UCSR0A & _BV(UDRE0)));
	UDR0 = (unsigned char) data;
}

/**********************************************************************
* Purpose: This function reads a character from the uart.
*
* Precondition:
*     stream - FILE stream must be declared before use.
*
* Postcondition:
*      Returns the character read by the uart as an int (for compatability).
*
************************************************************************/
int uart_getcharacter(FILE *stream)
{
	loop_until_bit_is_set(UCSR0A, RXC0); /* Wait until data exists. */
	return UDR0;
}

void uart_read_line(uint8_t *value, uint8_t size) {
	for (uint8_t i = 0; i < size; i++) {
		value[i] = uart_getchar();
		if (value[i] == '\r') {
			value[i] = '\0';
			break;
		}
	}
}
void uart_putchar(const uint32_t data)
{
	//int count = 0;
	//int temp = data;
	//do
	//{
	//	++count;
	//	temp /= 10;
	//}while(temp != 0);
	//char  sendbyte[count];
	char sendbyte[4];
	itoa(data,sendbyte,10);
	int charlength = strlen(sendbyte);
	for(int i =0; i < 4; i++)
	{
		UDR0 = sendbyte[i];
		loop_until_bit_is_set(UCSR0A, UDRE0);
		//printf(sendbyte[i]);
	}
}
uint8_t uart_getchar() {
	loop_until_bit_is_set(UCSR0A, RXC0);
	return UDR0;
}
void uart_init(uint32_t baudrate, uint8_t double_speed) {
	uint16_t ubrr = 0;
	if (double_speed) {
		UCSR0A = _BV(U2X0);  //Enable 2x speed
		ubrr = (F_CPU / (8UL * baudrate)) - 1;
		} else {
		ubrr = (F_CPU / (16UL * baudrate)) - 1;
	}
	UBRR0H = ubrr >> 8;
	UBRR0L = ubrr;

	UCSR0C &= ~(_BV(UMSEL01) | _BV(UMSEL00)); // enable asynchronous USART
	UCSR0C &= ~(_BV(UPM01) | _BV(UPM00)); // disable parity mode
	UCSR0C &= ~_BV(USBS0); // set 1-bit stop
	UCSR0C &= ~_BV(UCSZ02);
	UCSR0C |= _BV(UCSZ01) | _BV(UCSZ00); // set 8-bit data

	UCSR0B = _BV(RXEN0) | _BV(TXEN0);   // Enable RX and TX
}
