/*
 * bma220.h
 *
 * Created: 1/9/2018 9:28:38 AM
 *  Author: tapadhir.das
 */ 
