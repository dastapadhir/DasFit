/*
 * I2C_Master_C_file.c
 *
 * Created: 1/23/2018 1:29:41 PM
 *  Author: tapadhir.das
 */ 
