

#ifndef UARTDRIVER_H_
#define UARTDRIVER_H_

// Defines
#define BAUD 9600

// Function Prototypes
//void uart_init(void);
void uart_init(uint32_t baudrate, uint8_t double_speed);
int uart_putcharacter(char c, FILE *stream);
int uart_getcharacter(FILE *stream);
void uart_read_line(uint8_t *value, uint8_t size);
void uart_putchar(const uint32_t data);
uint8_t uart_getchar();
#endif /* UARTDRIVER_H_ */