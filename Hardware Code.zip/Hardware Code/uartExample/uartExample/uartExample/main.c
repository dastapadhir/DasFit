

/***********************************************************
//The default setting for the accelerometer is +-2g. The configuration
can always be changed by writing to the ACCEL_CONFIG register on the MPU6050.
Under the setting +-2g, the max and min values that can be read by the accelerometer
are +32768 and -32768. By doing simple division, I realized that the value of a g is 
16384.0f. So I used the value to divide all accelerometer coordinates by 
16384.0f, and then cast it to an int making the value before the decimal point remain
That was I can get each value to either be +1, 0, or -1. That makes it easy for my device to
detect proper accuracy needed. 
*************************************************************/

#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/twi.h>
#include <util/delay.h>
#include "uartDriver.h"


int I2CStart();
int SetGValue();
int I2CDriver();
int ReadZ();
int ReadY();
int ReadX();
void SteppingAlgorithm(valueX, valueY, valueZ);

//Counter values
int stepcounter = 0;
int counter = 0;

//Data values from Accelerometer
int valueX = 0;
int valueY = 0;
int valueZ = 0;

//transmit values from phone over bluetooth
char data= ' ';
char temparray[4];

//Threshold variables
int thresholdX = 0;
int thresholdY = 0;
int thresholdZ = 0;


int xprev = 0;
int yprev = 0;
int zprev = 0;

#define MPU6050 0x68 // MPU6050 address

int main(void)
{	
	//// Create File Pointers for in and out
	FILE uart_output = FDEV_SETUP_STREAM(uart_putcharacter, NULL, _FDEV_SETUP_WRITE);
	FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getcharacter, _FDEV_SETUP_READ);
	
	// Initialize the UART Driver
	//uart_init();
	uart_init(9600, 1);
	//// Hijack STDIN/STDOUT and send then to the UART Driver
	stdout = &uart_output;
	stdin  = &uart_input;
	sei();
	I2CStart();
	SetGValue();
	I2CDriver();
	return 0;
}
int I2CStart()
{
	/* Set TWI clock to 100 kHz */
	//TWBR = 0x48;
		
	/* Send Start */
	TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_START) {
		return -1;
	}
		
	/* Send SLA+W */
	TWDR = (MPU6050 << 1) | TW_WRITE; // SLA+W
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_SLA_ACK) {
		return -1;
	}
		
	/* Set PWR_MGMT_1 to wake up MPU6050-6050 */
	TWDR = 0x6B; // Send address of PWR_MGMT_1
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_DATA_ACK) {
		return -1;
	}
	TWDR = 0; // Set value of PWR_MGMT_1
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_DATA_ACK)
	{
		return -1;
	}
		
	/* Send Stop condition */
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
	_delay_ms(1); // Allow time for stop to send
}
int SetGValue()
{
	/* Send Start */
	TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_START) {
		return -1;
	}
	
	/* Send SLA+W */
	TWDR = (MPU6050 << 1) | TW_WRITE; // SLA+W
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_SLA_ACK) {
		return -1;
	}
	/********************
	+-2g = 0x00
	+-4g = 0x08
	+-8h = 0x10
	+-16g= 0x18
	********************/
	
	/* Set ACCEL_CONFIG to set up G value for MPU6050-6050 */
	TWDR = 0x1C; // Send address of ACCEL_CONFIG
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_DATA_ACK) {
		return -1;
	}
	TWDR = 0; // Set value of G value
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_DATA_ACK)
	{
		return -1;
	}
	
	/* Send Stop condition */
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
	_delay_ms(1); // Allow time for stop to send	
	
}
int I2CDriver() 
{
	while(1)
	{		
		ReadZ();
		ReadY();
		ReadX();
		SteppingAlgorithm(valueX,valueY,valueZ);
		counter++;
		memset(data, 0, 1);
		uart_read_line(data, 1);
		printf("a");
		//uart_putchar(stepcounter);
		if(data == 'O')
		{
			//printf("%c",stepcounter);
			//printf("Writing back data %d", stepcounter);
			//uart_putchar(20);
			//data = '\0';
		}
		//uart_print(data);
		_delay_ms(100); //150
	}
}
int ReadZ()
{
	/* Send Start */
	TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_START)
	{
		return -1;
	}
	/* Send SLA+W */
	TWDR = (MPU6050 << 1) | TW_WRITE; // SLA+W
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_SLA_ACK)
	{
		return -1;
	}
	/* Set Address in MPU-6050 to read */
	TWDR = 0x3F; // ACCEL_ZOUT_H, address to read at
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_DATA_ACK)
	{
		return -1;
	}
	/* Send Stop condition */
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
	_delay_ms(1);
	/* Send Start */
	TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_START)
	{
		return -1;
	}
	/* Send SLA+R */
	TWDR = (MPU6050 << 1) | TW_READ; // SLA+R
	TWCR = (1<<TWINT)|(1<<TWEN); // Start read
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MR_SLA_ACK)
	{
		return -1;
	}
	/* Read Register(s) */
	int16_t AcZ = 0;
	TWCR = (1<<TWINT)|(1<<TWEN)| _BV(TWEA); // Start Read, ACK enabled
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MR_DATA_ACK)
	{
		return -1;
	}
	AcZ = TWDR << 8; // Store high byte // read next byte // MPU-6050 automatically increments address to read from --> ACCEL_ZOUT_L
	TWCR = (1<<TWINT)|(1<<TWEN); // no TWEA--> send NACK after last byte
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MR_DATA_NACK)
	{
		return -1;
	}
	AcZ |= TWDR; // Store low byte
	/* Send Stop */
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
	_delay_ms(1);
	/* Print Value */
	valueZ = AcZ/16384.12f;
	if(counter == 0)
	{
		thresholdZ = valueZ;	
	}
	//printf("AcZ = %d g ", valueZ);
}
int ReadY()
{
	/* Send Start */
	TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_START)
	{
		return -1;
	}
	/* Send SLA+W */
	TWDR = (MPU6050 << 1) | TW_WRITE; // SLA+W
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_SLA_ACK)
	{
		return -1;
	}
	/* Set Address in MPU-6050 to read */
	TWDR = 0x3D; // ACCEL_YOUT_H, address to read at
	TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MT_DATA_ACK)
	{
		return -1;
	}
	/* Send Stop condition */
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
	_delay_ms(1);
	/* Send Start */
	TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_START)
	{
		return -1;
	}
	/* Send SLA+R */
	TWDR = (MPU6050 << 1) | TW_READ; // SLA+R
	TWCR = (1<<TWINT)|(1<<TWEN); // Start read
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MR_SLA_ACK)
	{
		return -1;
	}
	/* Read Register(s) */
	int16_t AcY = 0;
	TWCR = (1<<TWINT)|(1<<TWEN)| _BV(TWEA); // Start Read, ACK enabled
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MR_DATA_ACK)
	{
		return -1;
	}
	AcY = TWDR << 8; // Store high byte // read next byte // MPU-6050 automatically increments address to read from --> ACCEL_ZOUT_L
	TWCR = (1<<TWINT)|(1<<TWEN); // no TWEA--> send NACK after last byte
	while (!(TWCR & _BV(TWINT)));
	if ((TWSR & 0xF8) != TW_MR_DATA_NACK)
	{
		return -1;
	}
	AcY |= TWDR; // Store low byte
	/* Send Stop */
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
	_delay_ms(1);
	/* Print Value */
	valueY = AcY/16384.12f;
	if(counter == 0)
	{
		thresholdY = valueY;
	}
	//printf("AcY = %d g ", valueY);
}
int ReadX()
{
		/* Send Start */
		TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
		while (!(TWCR & _BV(TWINT)));
		if ((TWSR & 0xF8) != TW_START)
		{
			return -1;
		}
		/* Send SLA+W */
		TWDR = (MPU6050 << 1) | TW_WRITE; // SLA+W
		TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
		while (!(TWCR & _BV(TWINT)));
		if ((TWSR & 0xF8) != TW_MT_SLA_ACK)
		{
			return -1;
		}
		/* Set Address in MPU-6050 to read */
		TWDR = 0x3B; // ACCEL_XOUT_H, address to read at
		TWCR = (1<<TWINT)|(1<<TWEN); // Start transmission
		while (!(TWCR & _BV(TWINT)));
		if ((TWSR & 0xF8) != TW_MT_DATA_ACK)
		{
			return -1;
		}
		/* Send Stop condition */
		TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
		_delay_ms(1);
		/* Send Start */
		TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN) | _BV(TWEA);
		while (!(TWCR & _BV(TWINT)));
		if ((TWSR & 0xF8) != TW_START)
		{
			return -1;
		}
		/* Send SLA+R */
		TWDR = (MPU6050 << 1) | TW_READ; // SLA+R
		TWCR = (1<<TWINT)|(1<<TWEN); // Start read
		while (!(TWCR & _BV(TWINT)));
		if ((TWSR & 0xF8) != TW_MR_SLA_ACK)
		{
			return -1;
		}
		/* Read Register(s) */
		int16_t AcX = 0;
		TWCR = (1<<TWINT)|(1<<TWEN)| _BV(TWEA); // Start Read, ACK enabled
		while (!(TWCR & _BV(TWINT)));
		if ((TWSR & 0xF8) != TW_MR_DATA_ACK)
		{
			return -1;
		}
		AcX = TWDR << 8; // Store high byte // read next byte // MPU-6050 automatically increments address to read from --> ACCEL_ZOUT_L
		TWCR = (1<<TWINT)|(1<<TWEN); // no TWEA--> send NACK after last byte
		while (!(TWCR & _BV(TWINT)));
		if ((TWSR & 0xF8) != TW_MR_DATA_NACK)
		{
			return -1;
		}
		AcX |= TWDR; // Store low byte
		/* Send Stop */
		TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
		_delay_ms(1);
		/* Print Value */
		valueX = AcX/16384.12f;
		if(counter == 0)
		{
			thresholdX = valueX;
		}
		//printf("AcX = %d g \n", valueX);
} 
void SteppingAlgorithm(valueX, valueY, valueZ) //Testing for the chest value
{
	int thresholdcheck = 0;
	if(counter == 0)
	{
		xprev = thresholdX;
		yprev = thresholdY;
		zprev = thresholdZ;
	}
	else
	{
		if(valueX == thresholdX && valueY == thresholdY && valueZ == thresholdZ)
		{
			if(valueX == xprev && valueY == yprev && valueZ == zprev)
			{
				thresholdcheck = 0;
			}
			else
			{
				thresholdcheck = 1;
			}
		}
		if(counter == 2147483647)
		{
			counter = 0; 
		}
		
	}
	
	if(thresholdcheck == 1)
	{
		stepcounter = stepcounter + 2;
		printf("%d", stepcounter);
	}
	xprev = valueX;
	yprev = valueY;
	zprev = valueZ;
}



























